<?php
session_start();
include 'config.php';

// Check if the user is logged in
if (!isset($_SESSION['user_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Check if hall_id is provided
if (!isset($_GET['hall_id'])) {
    header('Location: halls.php');
    exit();
}

$hall_id = $_GET['hall_id'];
$user_id = $_SESSION['user_id']; // Assuming you store user_id in the session

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Fetch the booking date from the form
    $booking_date = $_POST['booking_date'];
    
    // Insert the booking into the database
    $stmt = $conn->prepare("INSERT INTO bookings (hall_id, user_id, booking_date) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $hall_id, $user_id, $booking_date);

    if ($stmt->execute()) {
        // Set a success message
        $_SESSION['success_message'] = "Hall booked successfully!";
        
        // Redirect to home page
        header('Location: index.php');
        exit();
    } else {
        // Handle error (optional)
        $_SESSION['error_message'] = "Booking failed. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Hall</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css"> <!-- Link to custom CSS -->
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="index.php">Banquet Booking</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="admin/admin_login.php">Admin</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="halls.php">Available Halls</a>
                </li>
                <?php if (isset($_SESSION['user_logged_in'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
    <div class="container mt-5">
        <h2>Book Hall</h2>
        <form method="POST">
            <div class="form-group">
                <label for="booking_date">Booking Date</label>
                <input type="date" class="form-control" id="booking_date" name="booking_date" required>
            </div>
            <button type="submit" class="btn btn-primary">Book Now</button>
        </form>
    </div>
</body>
</html>
