
<?php
session_start();
include '../config.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $hall_name = $_POST['hall_name'];
    $location = $_POST['location'];
    $capacity = $_POST['capacity'];
    $price = $_POST['price'];
    $available_from = $_POST['available_from'];
    $available_to = $_POST['available_to'];

    if (empty($hall_name) || empty($location) || empty($capacity) || empty($price) || empty($available_from) || empty($available_to)) {
        $error = "All fields are required.";
    } else {
        $stmt = $conn->prepare("INSERT INTO halls (hall_name, location, capacity, price, available_from, available_to) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('ssidsi', $hall_name, $location, $capacity, $price, $available_from, $available_to);

        if ($stmt->execute()) {
            header('Location: admin_dashboard.php');
            exit();
        } else {
            $error = "Failed to add hall. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Hall</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css"> <!-- User Panel CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
    body {
        background-color:#B0C4DE;
    }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Admin Panel</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="/banquet_booking1">User</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="admin_dashboard.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="add_hall.php">Add Hall</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_bookings.php">View Bookings</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container mt-5">
        <h2>Add New Hall</h2>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        <form action="" method="POST">
            <div class="form-group">
                <label for="hall_name">Hall Name</label>
                <input type="text" name="hall_name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="location">Location</label>
                <input type="text" name="location" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="capacity">Capacity</label>
                <input type="number" name="capacity" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="price">Price</label>
                <input type="number" name="price" step="0.01" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="available_from">Available From</label>
                <input type="date" name="available_from" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="available_to">Available To</label>
                <input type="date" name="available_to" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Add Hall</button>
        </form>
    </div>
</body>
</html>
