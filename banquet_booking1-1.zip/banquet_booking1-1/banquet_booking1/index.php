<?php
session_start();
include 'config.php';

// Fetch available halls
$halls = $conn->query("SELECT * FROM halls");

// Display success message if set
$success_message = isset($_SESSION['success_message']) ? $_SESSION['success_message'] : '';
$error_message = isset($_SESSION['error_message']) ? $_SESSION['error_message'] : '';

// Clear messages after displaying
unset($_SESSION['success_message']);
unset($_SESSION['error_message']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banquet Booking System</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/custom_style.css"> <!-- User Panel CSS -->

</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="logo">
    <a href="index.php">
        <img src="logo1.png" alt="Logo">
    </a> 
    </div><br><br>   
        <a class="navbar-brand" href="index.php">Banquet Booking</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="admin/admin_login.php">Admin</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="halls.php">Available Halls</a>
                </li>
                <?php if (isset($_SESSION['user_logged_in'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                    
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                <?php endif; ?>
                    
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <h2>Welcome to the Banquet Booking System</h2>

        <!-- Display success or error message -->
        <?php if ($success_message): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <p>Available Halls:</p>
        <div class="row">
            <?php while ($hall = $halls->fetch_assoc()): ?>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $hall['hall_name']; ?></h5>
                            <p class="card-text">Location: <?php echo $hall['location']; ?></p>
                            <p class="card-text">Capacity: <?php echo $hall['capacity']; ?></p>
                            <p class="card-text">Price: ₹<?php echo $hall['price']; ?> per day</p>
                            <a href="book_hall.php?hall_id=<?php echo $hall['id']; ?>" class="btn btn-primary">Book Now</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>

    <div class="footer">
        <b><p>&copy; 2024 Banquet Booking System</p></b>
    </div>
</body>
</html>
