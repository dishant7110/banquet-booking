<?php
session_start();
include 'config.php';

$halls = $conn->query("SELECT * FROM halls");

if (isset($_GET['success'])) {
    echo "<div class='alert alert-success'>Hall booked successfully!</div>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Halls</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/custom_style.css"> <!-- User Panel CSS -->
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="index.php">Banquet Booking</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="admin/admin_login.php">Admin</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="halls.php">Available Halls</a>
                </li>
                <?php if (isset($_SESSION['user_logged_in'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <h2>Available Halls</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>Hall Name</th>
                    <th>Location</th>
                    <th>Capacity</th>
                    <th>Price</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($hall = $halls->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $hall['hall_name']; ?></td>
                        <td><?php echo $hall['location']; ?></td>
                        <td><?php echo $hall['capacity']; ?></td>
                        <td><?php echo $hall['price']; ?></td>
                        <td>
                            <a href="book_hall.php?hall_id=<?php echo $hall['id']; ?>" class="btn btn-primary">Book Now</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
